package com.example.appfirebase.Class;

public class RoleClass {
    private String Role;

    public RoleClass() {
    }

    public RoleClass(String role) {
        Role = role;
    }

    public String getRole() {
        return Role;
    }

    public void setRole(String role) {
        Role = role;
    }
}
