package com.example.appfirebase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class chef_orders extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chef_orders);
    }
}