package com.example.appfirebase.classNotification;

public class MyResponse {

    public int success;
}
