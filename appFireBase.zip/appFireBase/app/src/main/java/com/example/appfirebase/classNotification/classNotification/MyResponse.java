package com.example.appfirebase.classNotification.classNotification;

public class MyResponse {

    public int success;
}
